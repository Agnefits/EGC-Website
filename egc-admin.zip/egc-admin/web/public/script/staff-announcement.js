document.addEventListener('DOMContentLoaded', () => { 
    const messageForm = document.getElementById('message-form');
    
    // Ensure the form exists before attaching the event listener
    if (messageForm) {
        messageForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const description = document.getElementById('description').value.trim();
            const fileInput = document.getElementById('fileInput');
            const formData = new FormData();

            if (!description) {
                alert('Please enter a description');
                return;
            }

            formData.append('description', description);

            // Append files to formData if available
            if (fileInput.files.length > 0) {
                for (const file of fileInput.files) {
                    formData.append('files', file);
                }
            }

            try {
                const response = await fetch('/send-announcement', {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    alert('Announcement sent successfully!');
                    loadAnnouncements();  // Load updated announcements
                    messageForm.reset();  // Reset form after success
                } else {
                    alert('Failed to send announcement');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            }
        });

        // Function to load announcements
        async function loadAnnouncements() {
            const messagesContainer = document.getElementById('messages-container');

            try {
                const response = await fetch('/get-announcements');
                if (response.ok) {
                    const announcements = await response.json();
                    messagesContainer.innerHTML = '';

                    announcements.forEach(announcement => {
                        const announcementDiv = document.createElement('div');
                        announcementDiv.innerHTML = `
                            <strong>${announcement.sender}</strong>: ${announcement.description}
                            <br>
                            <small>${new Date(announcement.date).toLocaleString()}</small>
                        `;
                        messagesContainer.appendChild(announcementDiv);
                    });
                } else {
                    messagesContainer.innerHTML = '<p>Failed to load announcements</p>';
                }
            } catch (error) {
                console.error('Error loading announcements:', error);
                messagesContainer.innerHTML = '<p>An error occurred while loading announcements.</p>';
            }
        }

        loadAnnouncements();  // Load announcements when the page is loaded
    } else {
        console.error('Form with ID "message-form" not found.');
    }
});

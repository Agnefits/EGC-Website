document.addEventListener('DOMContentLoaded', () => {
    const courseFilter = document.getElementById('coursefilter');
    const announcementContainer = document.getElementById('messages-container'); // Corrected to target messages-container

    // Function to fetch and display announcements
    async function loadAnnouncements() {
        try {
            const response = await fetch('/student/Announcements'); // Adjust the API endpoint if needed
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const announcements = await response.json(); // Expecting a JSON response

            // Clear existing announcements
            announcementContainer.innerHTML = '';

            // Loop through the announcements and display them
            announcements.forEach(announcement => {
                // Create a new announcement div
                const announcementDiv = document.createElement('div');
                announcementDiv.classList.add('announcement'); // Change 'comment2' to 'announcement'

                // Generate dynamic content
                announcementDiv.innerHTML = `
                    <div class="profile-container">
                        <img src="${announcement.profilePicture || '../img/default-profile.png'}" alt="Profile Picture">
                        <h4 class="sender-name">${announcement.senderName}</h4> <!-- Dynamic name -->
                        <p class="sender-info">Sent by: <span class="sender-name">${announcement.senderName}</span> 
                        (<span class="sender-role">${announcement.senderRole}</span>)</p> <!-- Dynamic sender role -->
                    </div>
                    <p class="announcement-text">${announcement.text}</p> <!-- Dynamic announcement text -->
                    <div class="file-download">
                        <img src="../img/image_f.png" alt="File Icon">
                        <a href="${announcement.fileLink}" download target="_blank" class="file-link">Download file</a> <!-- Dynamic file link -->
                    </div>
                `;

                // Append the new announcement to the main content
                announcementContainer.appendChild(announcementDiv);
            });
        } catch (error) {
            console.error('Error fetching announcements:', error);
            announcementContainer.innerHTML = '<p>Failed to load announcements</p>'; // Error message
        }
    }

    // Load announcements on page load
    loadAnnouncements();

    // Filter announcements based on selected course
    courseFilter.addEventListener('change', (e) => {
        const selectedCourse = e.target.value;
        const announcementRows = announcementContainer.querySelectorAll('.announcement'); // Get all announcement elements

        announcementRows.forEach(row => {
            // Here you may need to add a data attribute for course filtering
            if (selectedCourse === "" || row.getAttribute('data-course') === selectedCourse) {
                row.style.display = ''; // Show the row
            } else {
                row.style.display = 'none'; // Hide the row
            }
        });
    });
});

async function loadAnnouncements() {
    try {
        const response = await fetch('/student/Announcements'); // Ensure this matches your server route
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const announcements = await response.json();
        console.log('Announcements:', announcements);
        // Render announcements on your page
    } catch (error) {
        console.error('Error fetching announcements:', error);
    }
}

// Call the function to load announcements
loadAnnouncements();

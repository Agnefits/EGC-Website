class Configurations {
  static const databaseUrl = 'https://egc-website-eg-default-rtdb.firebaseio.com/';

  static const firebaseConfig = {
  'apiKey': "AIzaSyBB3OgrwvK467BUlfRfYPLP8JuOfF3U5bg",
  'authDomain': "egc-website-eg.firebaseapp.com",
  'projectId': "egc-website-eg",
  'storageBucket': "egc-website-eg.appspot.com",
  'messagingSenderId': "810596948775",
  'appId': "1:810596948775:web:e3808c2bccc71106e1e702",
  'measurementId': "G-Z0W2XJJSRS"
};
}